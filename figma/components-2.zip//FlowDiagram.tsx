import React from 'react';
import { FlowStep } from './FlowStep';
import { CurvedArrow } from './CurvedArrow';
import { 
  Smartphone, 
  User,
  ClipboardList,
  FileText,
  Upload, 
  Watch, 
  Brain, 
  Heart, 
  Activity, 
  Utensils, 
  Pill, 
  Building2,
  CreditCard, 
  Shield,
  TrendingUp,
  Calendar,
  Bell,
  CheckCircle2,
  Zap
} from 'lucide-react';
import { PhoneMockup } from './PhoneMockup';
import { NeuralNetwork } from './NeuralNetwork';
import { WearableSync } from './WearableSync';
import { HeartOutcome } from './HeartOutcome';

export function FlowDiagram() {
  return (
    <div className="max-w-6xl mx-auto px-8 py-20">
      {/* Header */}
      <div className="text-center mb-24">
        <div className="inline-flex items-center gap-4 mb-6">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-teal-500 to-emerald-500 rounded-3xl blur-xl opacity-30"></div>
            <div className="relative w-16 h-16 rounded-3xl bg-gradient-to-br from-teal-500 to-emerald-500 flex items-center justify-center shadow-xl">
              <Heart className="w-9 h-9 text-white" fill="white" strokeWidth={2} />
            </div>
          </div>
          <div>
            <h1 className="text-6xl tracking-tight text-slate-900">CardioShield</h1>
            <p className="text-teal-600 mt-1">AI-Powered Preventive Cardiology</p>
          </div>
        </div>
        <h2 className="text-4xl text-slate-900 mb-3">How CardioShield Works</h2>
        <p className="text-slate-600 max-w-2xl mx-auto text-lg">
          End-to-end journey from user engagement to preventive health outcomes
        </p>
      </div>

      {/* Flow Steps */}
      <div className="relative">
        {/* Step 1: User Signup */}
        <FlowStep
          number="01"
          title="User Signup"
          description="Seamless onboarding with mobile-first experience"
          color="teal"
        >
          <div className="grid grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-teal-100 border-2 border-teal-200 flex items-center justify-center">
                  <Smartphone className="w-7 h-7 text-teal-600" strokeWidth={2} />
                </div>
                <div>
                  <h4 className="text-slate-900 mb-1">Mobile Login</h4>
                  <p className="text-slate-600 text-sm">Quick sign-up via email or social auth</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-emerald-100 border-2 border-emerald-200 flex items-center justify-center">
                  <User className="w-7 h-7 text-emerald-600" strokeWidth={2} />
                </div>
                <div>
                  <h4 className="text-slate-900 mb-1">Profile Creation</h4>
                  <p className="text-slate-600 text-sm">Basic demographics and health goals</p>
                </div>
              </div>
              <div className="bg-gradient-to-br from-teal-50 to-emerald-50 rounded-2xl p-4 border border-teal-200/50">
                <div className="flex items-center gap-3 text-sm text-slate-700">
                  <CheckCircle2 className="w-5 h-5 text-teal-600" strokeWidth={2} />
                  <span>Account created in under 60 seconds</span>
                </div>
              </div>
            </div>
            <PhoneMockup screen="login" />
          </div>
        </FlowStep>

        <CurvedArrow />

        {/* Step 2: Onboarding Questionnaire */}
        <FlowStep
          number="02"
          title="Onboarding Questionnaire"
          description="Comprehensive lifestyle and symptoms assessment"
          color="emerald"
        >
          <div className="grid grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-teal-100 to-emerald-100 border-2 border-teal-200 flex items-center justify-center mx-auto mb-4">
                <ClipboardList className="w-10 h-10 text-teal-600" strokeWidth={2} />
              </div>
              <h4 className="text-slate-900 mb-2">Health History</h4>
              <p className="text-slate-600 text-sm">Medical conditions, medications, family history</p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-emerald-100 to-teal-100 border-2 border-emerald-200 flex items-center justify-center mx-auto mb-4">
                <Activity className="w-10 h-10 text-emerald-600" strokeWidth={2} />
              </div>
              <h4 className="text-slate-900 mb-2">Lifestyle Habits</h4>
              <p className="text-slate-600 text-sm">Diet, exercise, sleep, stress levels</p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-teal-100 to-emerald-100 border-2 border-teal-200 flex items-center justify-center mx-auto mb-4">
                <FileText className="w-10 h-10 text-teal-600" strokeWidth={2} />
              </div>
              <h4 className="text-slate-900 mb-2">Symptoms Check</h4>
              <p className="text-slate-600 text-sm">Current symptoms and risk indicators</p>
            </div>
          </div>
          <div className="mt-8 bg-slate-50 rounded-2xl p-6 border border-slate-200">
            <div className="grid grid-cols-5 gap-3">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className={`h-2 rounded-full ${i <= 3 ? 'bg-teal-400' : 'bg-slate-300'}`}></div>
              ))}
            </div>
            <p className="text-slate-600 text-sm mt-3 text-center">Interactive questionnaire - 5 minutes</p>
          </div>
        </FlowStep>

        <CurvedArrow />

        {/* Step 3: Data Intake Layer */}
        <FlowStep
          number="03"
          title="Data Intake Layer"
          description="Multi-source health data integration"
          color="teal"
        >
          <div className="grid grid-cols-2 gap-8">
            <div className="bg-gradient-to-br from-slate-50 to-teal-50/30 rounded-2xl p-8 border border-slate-200">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 rounded-2xl bg-white border-2 border-teal-200 flex items-center justify-center shadow-lg">
                  <Upload className="w-8 h-8 text-teal-600" strokeWidth={2} />
                </div>
                <div>
                  <h4 className="text-slate-900 mb-1">Medical Reports</h4>
                  <p className="text-slate-600 text-sm">Upload lab results & prescriptions</p>
                </div>
              </div>
              <div className="space-y-3">
                {['Blood Test Report', 'ECG Results', 'Lipid Profile'].map((report, idx) => (
                  <div key={idx} className="flex items-center gap-3 bg-white rounded-xl p-3 border border-slate-200 shadow-sm">
                    <FileText className="w-5 h-5 text-teal-600" strokeWidth={2} />
                    <span className="text-slate-700 text-sm flex-1">{report}</span>
                    <CheckCircle2 className="w-5 h-5 text-emerald-500" strokeWidth={2} />
                  </div>
                ))}
              </div>
            </div>

            <WearableSync />
          </div>
        </FlowStep>

        <CurvedArrow highlight />

        {/* Step 4: AI Core Layer */}
        <FlowStep
          number="04"
          title="AI Core Layer"
          description="Advanced risk prediction and pattern detection"
          color="gradient"
          highlight
        >
          <div className="grid grid-cols-5 gap-6 items-center">
            <div className="col-span-2 space-y-4">
              <div className="bg-white rounded-2xl p-5 border-2 border-teal-200 shadow-lg">
                <div className="flex items-center gap-3 mb-3">
                  <Zap className="w-6 h-6 text-amber-500" strokeWidth={2} />
                  <h4 className="text-slate-900">AI Analysis</h4>
                </div>
                <ul className="space-y-2 text-sm text-slate-700">
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-teal-500 mt-1.5"></div>
                    <span>Deep learning risk models</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-teal-500 mt-1.5"></div>
                    <span>Pattern recognition algorithms</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-teal-500 mt-1.5"></div>
                    <span>Predictive health scoring</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-teal-500 mt-1.5"></div>
                    <span>Continuous learning system</span>
                  </li>
                </ul>
              </div>
              <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-4 border border-amber-200">
                <div className="flex items-center gap-2 text-sm text-amber-900">
                  <TrendingUp className="w-5 h-5" strokeWidth={2} />
                  <span>98.5% prediction accuracy</span>
                </div>
              </div>
            </div>
            
            <div className="col-span-3">
              <NeuralNetwork />
            </div>
          </div>

          {/* AI Advantage Comparison */}
          <div className="mt-8 bg-white rounded-2xl border-2 border-teal-200 overflow-hidden">
            <div className="grid grid-cols-2 divide-x divide-slate-200">
              <div className="p-6 bg-slate-50">
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-slate-300 flex items-center justify-center">
                    <FileText className="w-5 h-5 text-slate-600" strokeWidth={2} />
                  </div>
                  <h4 className="text-slate-700">Traditional Approach</h4>
                </div>
                <ul className="space-y-3 text-sm text-slate-600">
                  <li className="flex items-start gap-2">
                    <span className="text-slate-400">•</span>
                    <span>Annual checkups only</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-slate-400">•</span>
                    <span>Reactive treatment</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-slate-400">•</span>
                    <span>Limited data visibility</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-slate-400">•</span>
                    <span>Generic recommendations</span>
                  </li>
                </ul>
              </div>
              <div className="p-6 bg-gradient-to-br from-teal-50 to-emerald-50">
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-500 flex items-center justify-center shadow-lg">
                    <Brain className="w-5 h-5 text-white" strokeWidth={2} />
                  </div>
                  <h4 className="text-slate-900">CardioShield AI</h4>
                </div>
                <ul className="space-y-3 text-sm text-slate-700">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-teal-600 mt-0.5" strokeWidth={2} />
                    <span>Continuous monitoring 24/7</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-teal-600 mt-0.5" strokeWidth={2} />
                    <span>Proactive risk prediction</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-teal-600 mt-0.5" strokeWidth={2} />
                    <span>Multi-source data integration</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-teal-600 mt-0.5" strokeWidth={2} />
                    <span>Personalized AI-driven plans</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </FlowStep>

        <CurvedArrow />

        {/* Step 5: Personalized Engagement */}
        <FlowStep
          number="05"
          title="Personalized Engagement"
          description="Daily nudges and actionable health recommendations"
          color="emerald"
        >
          <div className="grid grid-cols-2 gap-8 items-center">
            <PhoneMockup screen="dashboard" />
            
            <div className="space-y-6">
              <div className="bg-white rounded-2xl p-5 border-2 border-teal-200 shadow-lg">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-500 flex items-center justify-center">
                    <Utensils className="w-6 h-6 text-white" strokeWidth={2} />
                  </div>
                  <div>
                    <h4 className="text-slate-900">Nutrition Plan</h4>
                    <p className="text-slate-600 text-sm">Heart-healthy meal suggestions</p>
                  </div>
                </div>
                <div className="bg-emerald-50 rounded-xl p-3 text-sm text-slate-700">
                  Reduce sodium intake by 500mg/day
                </div>
              </div>

              <div className="bg-white rounded-2xl p-5 border-2 border-emerald-200 shadow-lg">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center">
                    <Activity className="w-6 h-6 text-white" strokeWidth={2} />
                  </div>
                  <div>
                    <h4 className="text-slate-900">Exercise Goals</h4>
                    <p className="text-slate-600 text-sm">Personalized activity targets</p>
                  </div>
                </div>
                <div className="bg-teal-50 rounded-xl p-3 text-sm text-slate-700">
                  30 min moderate cardio, 5x/week
                </div>
              </div>

              <div className="bg-white rounded-2xl p-5 border-2 border-teal-200 shadow-lg">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-500 flex items-center justify-center">
                    <Pill className="w-6 h-6 text-white" strokeWidth={2} />
                  </div>
                  <div>
                    <h4 className="text-slate-900">Medication Reminders</h4>
                    <p className="text-slate-600 text-sm">Never miss a dose</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 bg-blue-50 rounded-xl p-3 text-sm text-slate-700">
                  <Bell className="w-4 h-4 text-blue-600" strokeWidth={2} />
                  <span>Daily reminders at 8 AM & 8 PM</span>
                </div>
              </div>
            </div>
          </div>
        </FlowStep>

        <CurvedArrow />

        {/* Step 6: Outcome Layer */}
        <FlowStep
          number="06"
          title="Outcome Layer"
          description="Measurable preventive health outcomes"
          color="gradient"
          highlight
        >
          <div className="flex items-center justify-center">
            <HeartOutcome />
          </div>
          <div className="grid grid-cols-4 gap-6 mt-8">
            <div className="bg-white rounded-2xl p-5 border border-slate-200 text-center shadow-lg">
              <div className="text-3xl text-teal-600 mb-2">-35%</div>
              <p className="text-slate-700 text-sm">Risk Reduction</p>
            </div>
            <div className="bg-white rounded-2xl p-5 border border-slate-200 text-center shadow-lg">
              <div className="text-3xl text-emerald-600 mb-2">89%</div>
              <p className="text-slate-700 text-sm">User Adherence</p>
            </div>
            <div className="bg-white rounded-2xl p-5 border border-slate-200 text-center shadow-lg">
              <div className="text-3xl text-teal-600 mb-2">24/7</div>
              <p className="text-slate-700 text-sm">Monitoring</p>
            </div>
            <div className="bg-white rounded-2xl p-5 border border-slate-200 text-center shadow-lg">
              <div className="text-3xl text-emerald-600 mb-2">98%</div>
              <p className="text-slate-700 text-sm">Satisfaction</p>
            </div>
          </div>
        </FlowStep>

        <CurvedArrow />

        {/* Step 7: Business Backbone */}
        <FlowStep
          number="07"
          title="Business Backbone"
          description="Sustainable revenue model with clinical partnerships"
          color="slate"
        >
          <div className="grid grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-slate-50 to-slate-100 rounded-2xl p-6 border-2 border-slate-300 text-center">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-slate-600 to-slate-700 flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Building2 className="w-8 h-8 text-white" strokeWidth={2} />
              </div>
              <h4 className="text-slate-900 mb-2">Lab Partnerships</h4>
              <p className="text-slate-600 text-sm mb-4">Network of 500+ diagnostic centers</p>
              <div className="bg-white rounded-xl p-3 text-sm text-slate-700">
                Seamless test booking & result integration
              </div>
            </div>

            <div className="bg-gradient-to-br from-teal-50 to-emerald-50 rounded-2xl p-6 border-2 border-teal-300 text-center">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-teal-600 to-emerald-600 flex items-center justify-center mx-auto mb-4 shadow-lg">
                <CreditCard className="w-8 h-8 text-white" strokeWidth={2} />
              </div>
              <h4 className="text-slate-900 mb-2">Subscription Tiers</h4>
              <p className="text-slate-600 text-sm mb-4">Basic, Premium, Enterprise plans</p>
              <div className="space-y-2">
                <div className="bg-white rounded-lg p-2 text-xs text-slate-700 border border-teal-200">₹499/mo - Basic</div>
                <div className="bg-gradient-to-r from-teal-500 to-emerald-500 rounded-lg p-2 text-xs text-white shadow-lg">₹999/mo - Premium</div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-6 border-2 border-amber-300 text-center">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Shield className="w-8 h-8 text-white" strokeWidth={2} />
              </div>
              <h4 className="text-slate-900 mb-2">Data Security</h4>
              <p className="text-slate-600 text-sm mb-4">HIPAA & GDPR compliant</p>
              <div className="bg-white rounded-xl p-3 text-sm text-slate-700">
                End-to-end encryption • Secure cloud storage
              </div>
            </div>
          </div>
        </FlowStep>
      </div>

      {/* Footer */}
      <div className="text-center mt-24 pt-12 border-t-2 border-slate-200">
        <div className="flex items-center justify-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-500 flex items-center justify-center">
            <Heart className="w-6 h-6 text-white" fill="white" strokeWidth={2} />
          </div>
          <p className="text-slate-900 text-lg">CardioShield</p>
        </div>
        <p className="text-slate-600">
          Premium AI-Powered Preventive Cardiology Platform
        </p>
        <p className="text-slate-500 text-sm mt-2">
          Clinically validated • Data-driven • Personalized care
        </p>
      </div>
    </div>
  );
}
